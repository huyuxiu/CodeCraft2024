#include "iointerface.h"
#include "model.h"
#include "util.h"
#include "const.h"

#include<iostream>
#include<cstring>
namespace IO {
    void init() {
		//TODO 实现初始化地图的功能
		memset(map,' ',sizeof map);//地图初始化
		memset(block,-1,sizeof block);
		for(int i = 0;i<conVar::maxX+1;i++){
			scanf("%s",map[i]);
		}
		for(int i = 0;i<10;i++){
			/*     读取泊点信息     */
			int id, x, y, time, velocity;
			scanf("%d %d %d %d %d",&id,&x,&y,&time,&velocity);
			berth[id].setId(id);
			Position pos(x,y);
			berth[id].setPos(pos);
			berth[id].setTransport_time(time);
			berth[id].setVelocity(velocity);
			berth[id].presure = 0;

		}
		int dist[conVar::maxX+5][conVar::maxY+5];//临时距离数组
		/*     暴搜10次，给每个点标记泊位队列     */
		for(int i =0;i<10;i++){
			memset(dist,-1,sizeof dist);
			bfsBerth(berth[i].getPosition(),dist);

			for(int x =0;x<conVar::maxX+1;x++){
				for(int y = 0;y<conVar::maxY+1;y++){
					berthQueue[x][y][i] = {i,dist[x][y]};
				}
			}

		}

		/*     对暴搜的结果进行排序     */
	    for (int i = 0; i <= conVar::maxX; ++i) {
		    for (int j = 0; j <= conVar::maxY; ++j) {
			    std::sort(berthQueue[i][j], berthQueue[i][j] + 10, sortGoodsBerthDist);
		    }
	    }

		/*     floodfill     */
		berth[0].setBlockId(0);         //最先开始floodfill的泊位设置联通块id为0
	    for(int i =0;i<10;i++){
		    Position pos = berth[i].getPosition();
		    if(block[pos.x][pos.y]==-1){
				floodFill(pos,i);
		    }
			else{
				berth[i].setBlockId(block[pos.x][pos.y]);
			}
	    }


		scanf("%d",&shipCapacity);
		for(int i =0;i<5;i++){
			ship[i].setCapacity(shipCapacity);
		}
		memset(shipTargetBerth,0,sizeof shipTargetBerth);
	    char ok[100];
	    scanf("%s",&ok);        //读帧结束

		//多源bfs初始化地图上所有点到所有泊位的距离
		puts("OK");
		std::fflush(stdout);

	}
	void readFrame(){
		scanf("%d %d",&frameId,&money);
		scanf("%d",&k);
		int x,y,value,status,carry,berthId;
		Position pos(0,0);
		for(int i =0;i<k;i++){
			scanf("%d %d %d",&x,&y,&value);
			pos.x = x,pos.y = y;
			if(getBlockId(pos)==-1) continue;
			if(isCollision(pos)) continue;
			goods[goodsId].value = value,goods[goodsId].deathId = frameId+1000,goods[goodsId].pos = pos;
			int minPri = -1;
			int minId = 0;
//			for(int j = 0;j<10;j++){
//          使用优先队列这里就不用判断最近泊点了
//				int pri = priorityGoodsBerthSHip(goods[goodsId],berth[j]);  //泊点优先级,优先级越小运送到泊点代价越小
//				if(pri<minPri){
//					minPri = pri;
//					minId = j;
//				}
//			}
			for(int j = 0;j<10;j++){
				if(berth[berthQueue[x][y][j].first].getBlockId()==block[x][y]){
					/*     判断泊位连通性     */
					goods[goodsId].berthDist = berthQueue[x][y][j].second;
					goods[goodsId].priority = calPriorityGoodsBerth(value,goods[goodsId].berthDist);
					goodsHeap[berthQueue[x][y][0].first].push(goods[goodsId++]);
					break;
				}

			}



//			if(value>maxValue){
//				maxValue = value;
//				goods[goodsId].priority = -1;//优先去拿最贵的货
//			}


		}

		for(int i = 0;i<10;i++){
			/*       读取机器人状态       */
			scanf("%d %d %d %d",&carry,&x,&y,&status);
            pos.x = x,pos.y = y;
			robot[i].setId(i);
			robot[i].setPosition(pos);
			robot[i].setStatus(status);
			robot[i].setCarry(carry);
			robot[i].setBerthId(berthQueue[x][y][0].first);
		}

        for(int i = 0;i<5;i++){
			/*     读取船只信息     */
			scanf("%d %d",&status,&berthId);
			ship[i].setBerthId(berthId);
			ship[i].setStatus(status);
        }
		char ok[100];
		scanf("%s",&ok);        //读帧结束
	}
	namespace ROBOT{
		void move(int id,int direction){
			printf("move %d %d\n",id,direction);
		}
		void get(int id){
			printf("get %d\n",id);
		}
		void pull(int id){
			printf("pull %d\n",id);
		}
	}
	namespace SHIP{
		void ship(int shipId,int berthId){
			printf("ship %d %d\n",shipId,berthId);
		}
		void go(int shipId){
			printf("go %d\n",shipId);
		}
	}
}